package br.com.fiap.beans;

public class Empresa {
   private String nomeEmpresa;
   private String segmento;
   private int tamanhoEmpresa;
   private String cargo;
   private String pais;
   private String estado;

   public Empresa() {
   }

   public Empresa(String nomeEmpresa, String segmento, int tamanhoEmpresa, String cargo, String pais, String estado) {
      this.nomeEmpresa = nomeEmpresa;
      this.segmento = segmento;
      this.tamanhoEmpresa = tamanhoEmpresa;
      this.cargo = cargo;
      this.pais = pais;
      this.estado = estado;
   }

   public String getNomeEmpresa() {
      return this.nomeEmpresa;
   }

   public String getSegmento() {
      return this.segmento;
   }

   public int getTamanhoEmpresa() {
      return this.tamanhoEmpresa;
   }

   public String getCargo() {
      return this.cargo;
   }

   public String getPais() {
      return this.pais;
   }

   public String getEstado() {
      return this.estado;
   }

   public void setNomeEmpresa(String nomeEmpresa) {
      this.nomeEmpresa = nomeEmpresa;
   }

   public void setSegmento(String segmento) {
      this.segmento = segmento;
   }

   public void setTamanhoEmpresa(int tamanhoEmpresa) {
      this.tamanhoEmpresa = tamanhoEmpresa;
   }

   public void setCargo(String cargo) {
      this.cargo = cargo;
   }

   public void setPais(String pais) {
      this.pais = pais;
   }

   public void setEstado(String estado) {
      this.estado = estado;
   }
}
