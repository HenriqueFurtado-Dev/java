package br.com.fiap.beans;

import java.awt.Component;
import javax.swing.Icon;
import javax.swing.JOptionPane;

public class Acessibilidade {
   private String tipoDeficiencia;

   public Acessibilidade() {
   }

   public void perguntarDeficiencia() {
      String resposta = JOptionPane.showInputDialog("Voce possui alguma deficiencia? (1 para sim, 2 para nao):");
      this.tipoDeficiencia = "";
      if (resposta != null && !resposta.isEmpty()) {
         int escolha = Integer.parseInt(resposta);
         if (escolha == 1) {
            String[] opcoesDeficiencia = new String[]{"Deficiencia visual", "Deficiencia auditiva", "Outra deficiencia"};
            resposta = (String)JOptionPane.showInputDialog((Component)null, "Selecione o tipo de deficiencia:", "Escolha sua deficiencia", 3, (Icon)null, opcoesDeficiencia, opcoesDeficiencia[0]);
            if (resposta != null) {
               this.tipoDeficiencia = resposta;
            } else {
               this.tipoDeficiencia = "Nenhuma deficieancia selecionada.";
            }
         } else if (escolha == 2) {
            this.tipoDeficiencia = "Nenhuma deficiencia";
         } else {
            this.tipoDeficiencia = "Opcao invalida. Por favor, selecione 1 para sim ou 2 para nao.";
         }
      } else {
         this.tipoDeficiencia = "Resposta invalida. Por favor, selecione 1 para sim ou 2 para nao.";
      }

      JOptionPane.showMessageDialog((Component)null, "O usuario possui: " + this.tipoDeficiencia);
   }

   public String getTipoDeficiencia() {
      return this.tipoDeficiencia;
   }
}
